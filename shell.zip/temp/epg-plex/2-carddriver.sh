#!/bin/bash
sudo apt install -y libpcsclite-dev pcscd pcsc-tools libccid
pcsc_scan 

