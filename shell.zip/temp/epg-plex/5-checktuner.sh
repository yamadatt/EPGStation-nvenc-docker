#!/bin/bash
ls -l /dev/px*
