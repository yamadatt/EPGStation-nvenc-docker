#!/bin/sh
# p2a-editsamba.sh
gedit ./data/p2x-smb.config
